package com.cap;

import javax.jws.WebService;

@WebService(endpointInterface="com.cap.CalculateSimpleInt")
public class CalculateSimpleIntImpl implements CalculateSimpleInt{

	@Override
	public int calSimpleInt(int p, int r, int t) {
		
		
		return (p*r*t)/100;
	}
	
	

}
