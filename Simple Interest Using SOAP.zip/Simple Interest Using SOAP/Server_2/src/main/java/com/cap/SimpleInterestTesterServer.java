package com.cap;

import javax.xml.ws.Endpoint;



public class SimpleInterestTesterServer {

	public static void main(String[] args) {
		Endpoint.publish("http://localhost:7704/ws/CalculateSimpleInt", new CalculateSimpleIntImpl());

	}

}
