/**
 * 
 */
function validate(){
	var t=false;
	var uname=form1.uname.value;
	var pwd=form1.pwd.value;
	if(uname=="" ||uname==null){
		document.getElementById('usererrormsg').innerHTML="Username is Mandatory";
		t=false;
		
	}else if(pwd=="" || pwd==null){
		document.getElementById('usererrormsg').innerHTML="";
		document.getElementById('personerrormsg').innerHTML="Enter your password";
		t=false;
	}else{
		t=true;
	}
	return t;
}