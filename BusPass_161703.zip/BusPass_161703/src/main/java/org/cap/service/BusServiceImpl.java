package org.cap.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.cap.dao.IBusDAO;
import org.cap.dao.BusDAOImpl;
import org.cap.model.LoginBean;
import org.cap.model.PassRequestBean;
import org.cap.model.RouteBean;
import org.cap.model.TransactionBean;

public class BusServiceImpl implements IBusService {
	
	IBusDAO loginDAO = new BusDAOImpl();
	
	
	@Override
	public boolean checkUser(LoginBean loginBean) {
		if(loginDAO.checkUser(loginBean)) {
			return true;
		}else {
			return false;
		}
	}
	
	
	@Override
	public PassRequestBean createRequest(PassRequestBean busBean) {
		if(loginDAO.createRequest(busBean) != null)
			return busBean;
      return null;
		
	}
	
	
	@Override
	public List<RouteBean> listAllRoutes() {
		List<RouteBean> routeList=new ArrayList<>();
		routeList = loginDAO.listAllRoutes();
		return routeList;
	}
	
	@Override
	public RouteBean addRoute(RouteBean newroute) {
		if(loginDAO.addRoute(newroute)!=null) {
			return newroute;
		}
		return null;
	}
	
	@Override
	public List<String> PendingReqServlet() {
		List<String> plist=new ArrayList<>();
		plist=loginDAO.PendingReqServlet();
		return plist;
	}
	@Override
	public List<PassRequestBean> pendingDetails() {
		List<PassRequestBean> pendingList=loginDAO.pendingDetails();
		if(pendingList!=null)
			return pendingList;
		
		return null;
		
	}
	@Override
	public List<PassRequestBean> pendingDetailsOfEmp(String empid) {
		List<PassRequestBean> pendingList=loginDAO.pendingDetailsOfEmp(empid);
		if(pendingList!=null)
			return pendingList;
		return null;
	}
	@Override
	public Integer transaction(TransactionBean transaction) {
		Integer transaction_id=loginDAO.transaction(transaction);
		return transaction_id;
	}
	@Override
	public List<TransactionBean> monthlyReport(LocalDate firstdate, LocalDate lastdate) {
		List<TransactionBean> tranBean=loginDAO.monthlyReport(firstdate, lastdate);
		if(tranBean!=null)
			return tranBean;
		return null;
	
	}

}
