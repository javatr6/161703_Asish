package org.cap.dao;

import java.time.LocalDate;
import java.util.List;

import org.cap.model.LoginBean;
import org.cap.model.PassRequestBean;
import org.cap.model.RouteBean;
import org.cap.model.TransactionBean;

public interface IBusDAO {
	public abstract boolean checkUser(LoginBean loginBean);
	public abstract PassRequestBean createRequest(PassRequestBean passRequestBean) ;
	public abstract List<RouteBean> listAllRoutes();
	public abstract RouteBean addRoute(RouteBean newroute);
	public abstract List<String> PendingReqServlet();
	
	public abstract List<PassRequestBean> pendingDetails();
	public abstract List<PassRequestBean> pendingDetailsOfEmp(String empid);
	public abstract Integer transaction(TransactionBean transaction);
	public List<TransactionBean> monthlyReport(LocalDate fdate, LocalDate tdate); 
}
