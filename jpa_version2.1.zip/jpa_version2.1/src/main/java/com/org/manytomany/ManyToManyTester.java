package com.org.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class ManyToManyTester {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Events java=new Events();
		java.setEventId(1);
		java.setEventName("JAVA");
		
		Events oracle=new Events();
		oracle.setEventId(2);
		oracle.setEventName("ORACLE");
		
		Events dotnet=new Events();
		dotnet.setEventId(3);
		dotnet.setEventName("DOTNET");
		
		Delegates tom=new Delegates(1, "tom");
		tom.getEvents().add(java);
		Delegates joe=new Delegates(2, "joe");
		joe.getEvents().add(oracle);
		Delegates jack=new Delegates(3,"jack");
		jack.getEvents().add(dotnet);
		
		entityManager.persist(tom);
		entityManager.persist(java);
		entityManager.persist(joe);
		entityManager.persist(oracle);
		entityManager.persist(jack);
		entityManager.persist(dotnet);
		
		transaction.commit();
		entityManager.close();
		
		
		
	}

}
