package com.capg.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		
		Customer tom=new Customer("tom","jerry",45000);
		Address address=new Address(1001,"North avvenue",tom);
		
		entityManager.persist(tom);
		entityManager.persist(address);
		transaction.begin();
		transaction.commit();
		entityManager.close();

	}

}
